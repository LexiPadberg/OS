#include <stdio.h>    /* for printf */
#include <stdlib.h>   /* for string to integer conversion, random numbers */
#include "mem.h"

/*
  The main program will accept four paramemters on the command line.
  The first parameter is the memory size.  The second parameter is the
  duration of the each simulation run.  The third parameter is the
  number of times to repeat each experiment (ie. number of runs). The
  fourth parameter is a random number seed. Here is an example command
  line:

  ./hw7 1000 3000 100 1235

  This means that your program should initialize physical memory to
  1,000 units, perform 100 runs with each run taking 3000 units of
  time, and the random number generator should be seeded (one time)
  with the value 1235.
*/

int main(int argc, char** argv)
{  

    //input 
	int mem_size = atoi(argv[1]);
	int duration_sim = atoi(argv[2]);
	int num_runs = atoi(argv[3]);
	int rand_num_seed = atoi(argv[4]);
	
    
    //start by initializing memory to the given memory size input
    mem_init(mem_size);

    //For each placement algorithm you will average and display 
    //the external fragmentation results, number of probes, and number of allocation
    //failures. Thus the output will consist of nine different lines

    //best fit output and results
    srand(rand_num_seed);

    mem_clear();
    
    double probe_bf = 0.0;
    double frag_bf = 0.0;
    double fails_bf =0.0;

     for(int i=0; i<num_runs;i++){
        for(int j = 0; j < duration_sim; j++) {
        int size = rand() % (MAX_REQUEST_SIZE - MIN_REQUEST_SIZE) + MIN_REQUEST_SIZE;
        int duration = rand() % (MAX_DURATION - MIN_DURATION ) + MIN_DURATION;
      
        int probes = mem_allocate(BESTFIT, size, duration);
            if(probes == -1) {
                //count all the times the memory allocate fails (when -1 is returned)
			    fails_bf++;
			}
			else {
                //count all the times it passes
				probe_bf += probes;
			}
			mem_single_time_unit_transpired();
		}
		//get fragments from mem.c function
		frag_bf += mem_fragment_count(MIN_REQUEST_SIZE - 1);
		
		mem_clear();
	}
        double avg_frag_bf = frag_bf/num_runs;
        double avg_probe_bf = probe_bf/num_runs/duration_sim;
        double avg_fails_bf =fails_bf/num_runs;
 
	    printf("BEST FIT: \n");
        printf("Average amount of fragmentations: %.6f\n", avg_frag_bf);
	    printf("Average number probes: %.6f\n", avg_probe_bf);
        printf("Average number of allocation failures: %.6f\n", avg_fails_bf);


    //first fit output and results
    double probe_ff = 0.0;
    double frag_ff = 0.0;
    double fails_ff =0.0;
    srand(rand_num_seed);   

    mem_clear();
   
    for(int i=0; i<num_runs;i++){
        for(int j = 0; j < duration_sim; j++) {
        int size = rand() % (MAX_REQUEST_SIZE - MIN_REQUEST_SIZE) + MIN_REQUEST_SIZE;
        int duration = rand() % (MAX_DURATION - MIN_DURATION ) + MIN_DURATION;
        
        int probes = mem_allocate(FIRSTFIT, size, duration);

            if(probes == -1) {
                //count all the times the memory allocate fails (when -1 is returned)
			    fails_ff++;
			}
			else {
                //count all the times it passes
				probe_ff += probes;
			}
			mem_single_time_unit_transpired();
		}
		//get fragments from mem.c function
		frag_ff += mem_fragment_count(MIN_REQUEST_SIZE - 1);
		
		mem_clear();
	}
        double avg_probe_ff = probe_ff/num_runs/duration_sim;
        double avg_frag_ff = frag_ff/num_runs;
        double avg_fails_ff =fails_ff/num_runs;
 
	    printf("FIRST FIT: \n");
        printf("Average amount of fragmentations: %.6f\n", avg_frag_ff);
	    printf("Average number probes: %.6f\n", avg_probe_ff);
        printf("Average number of allocation failures: %.6f\n", avg_fails_ff);
    
    //next fit output and results
    double probe_nf = 0.0;
    double frag_nf = 0.0;
    double fails_nf =0.0;
    srand(rand_num_seed);   

    mem_clear();

        for(int i=0; i<num_runs;i++){
        for(int j = 0; j < duration_sim; j++) {
        int size = rand() % (MAX_REQUEST_SIZE - MIN_REQUEST_SIZE) + MIN_REQUEST_SIZE;
        int duration = rand() % (MAX_DURATION - MIN_DURATION ) + MIN_DURATION;
        
        int probes = mem_allocate(NEXTFIT, size, duration);

            if(probes == -1) {
                //count all the times the memory allocate fails (when -1 is returned)
			    fails_nf ++;
			}
			else {
                //count all the times it passes
				probe_nf += probes;
			}
			mem_single_time_unit_transpired();
		}
		//get fragments from mem.c function
		frag_nf += mem_fragment_count(MIN_REQUEST_SIZE - 1);
		
		mem_clear();
	    }
        double avg_probe_nf = probe_nf/num_runs/duration_sim;
        double avg_frag_nf = frag_nf/num_runs;
        double avg_fails_nf =fails_nf/num_runs;


	    printf("NEXT FIT: \n");
        printf("Average amount of fragmentations: %.6f\n", avg_frag_nf);
	    printf("Average number probes: %.6f\n", avg_probe_nf);
        printf("Average number of allocation failures: %.6f\n", avg_fails_nf);
   

    // Free allocated memory
    mem_free();

  return 0;
}